package br.com.fiap3espa.Auto_Escola_3ESPA;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoEscola3EspaApplication {
	public static void main(String[] args) {
		SpringApplication.run(AutoEscola3EspaApplication.class, args);
	}

	// Instruções pro Postman

	//{
	//	"nome": "Bolsonaro",
	//		"email": "presonapapuda@stf.com",
	//		"cnh": "55519900020",
	//		"especialidade": "Carros",
	//		"endereço": {
	//	"logradouro": "Rua muito feia",
	//			"numero": "300",
	//			"complemento": "Presidio",
	//			"bairro": "Ala 103",
	//			"cidade": "São Paulo",
	//			"uf": "SP",
	//			"cep": "06636140"
	//}
	//}

}
