package br.com.fiap3espa.Auto_Escola_3ESPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoEscola3EspaApplicationTests {

	@Test
	void contextLoads() {
	}

}
